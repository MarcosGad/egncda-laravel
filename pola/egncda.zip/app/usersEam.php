<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usersEam extends Model
{
    protected $guarded = [];
}
