<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class comment_eams extends Model
{
    protected $guarded = [];
}
