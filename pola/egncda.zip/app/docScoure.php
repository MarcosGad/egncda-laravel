<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class docScoure extends Model
{
    protected $guarded = [];
}
