<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class miscellaneouscurriculum extends Model
{
    protected $fillable = [
        'name','icon'
    ];
}
