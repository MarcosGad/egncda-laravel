<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class basicManagement extends Model
{
    protected $fillable = [
        'name','icon'
    ];
}
