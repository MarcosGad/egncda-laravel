<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class oncolcgycurriculums extends Model
{
    protected $fillable = [
        'name','icon'
    ]
}
