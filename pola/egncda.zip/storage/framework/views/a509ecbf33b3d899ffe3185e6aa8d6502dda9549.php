<?php if(auth()->user()->admin): ?>

<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
<div class="body-admin">
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4">

            <ul class="nav flex-column">
                
            
            <li class="nav-item <?php echo e(request()->is('dashboard')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li> 
            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fas fa-plus"></i> Add</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>"><i class="fas fa-newspaper"></i> Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>"><i class="fas fa-star-of-life"></i> Conferences</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('users')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('users')); ?>"><i class="fas fa-users"></i> Users</a>
            </li> 
            <!-- logout -->
                <li class="nav-item <?php echo e(request()->is('logout')  ? 'active' : null); ?>">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
                         Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>

            </ul> 
            
            </div>
            <div class="col-lg-10 col-sm-8">

                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                            <div class="card card-exam-one">
                                <div class="card-header">Create new Question</div>

                                <div class="card-body">
                                <form action="/questionnaires/<?php echo e($questionnaire->id); ?>/questions" method="post"> 
                                    <?php echo csrf_field(); ?>

                                  <div class="form-group">
                                     <label for="question">Question</label>
                                     <textarea class="form-control" rows="5" id="question" name="question[question]" value="<?php echo e(old('question.question')); ?>"  placeholder="Enter question"  required ></textarea>
                                        <?php $__errorArgs = ['question.question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>


                                    <div class="form-group">
                                    <fieldset>
                                        <legend>Choices</legend>
                                            <div>
                                                <div class="form-group">
                                                    <label for="answer1">A</label>
                                                    <input name="answers[][answer]" value="<?php echo e(old('answers.0.answer')); ?>" type="text" class="form-control" id="answer1" aria-describedby="answer1Help" placeholder="Enter A">

                                                        <?php $__errorArgs = ['answers.0.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="form-group">
                                                    <label for="answer2">B</label>
                                                    <input name="answers[][answer]" value="<?php echo e(old('answers.1.answer')); ?>" type="text" class="form-control" id="answer2" aria-describedby="answer1Help" placeholder="Enter B">

                                                        <?php $__errorArgs = ['answers.1.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="form-group">
                                                    <label for="answer3">C</label>
                                                    <input name="answers[][answer]" value="<?php echo e(old('answers.2.answer')); ?>" type="text" class="form-control" id="answer3" aria-describedby="answer1Help" placeholder="Enter C">

                                                        <?php $__errorArgs = ['answers.2.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="form-group">
                                                    <label for="answer4">D</label>
                                                    <input name="answers[][answer]" value="<?php echo e(old('answers.3.answer')); ?>" type="text" class="form-control" id="answer4" aria-describedby="answer1Help" placeholder="Enter D">

                                                        <?php $__errorArgs = ['answers.3.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>


                                    </fieldset>
                                    </div>

                                    <div class="form-group">
                                        <label for="number_answer">The correct answer</label>
                                        <select class="form-control" id="number_answer" name="question[number_answer]">
                                            <option value="1">A</option>
                                            <option value="2">B</option>
                                            <option value="3">C</option>
                                            <option value="4">D</option>
                                        </select>

                                        <?php $__errorArgs = ['question.number_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                
                                    <button type="submit" class="btn btn-primary">Create Question</button>

                                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</div>
</div>
</div>

<div class="pola">
</div>

<div class="footer">

<div class="container">
    <div class="row">
        <div class="col-lg-4 footer-ph">
           
        <img src="../../../img/logo-footer-final.png" class="logo-about" height="100px">
         

            </div>
            <div class="col-lg-4">
            
            
            <p class="loginas-footer">Services</p>
            <ul class="ul-footer">
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('welcome')); ?>">Home</a></li>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('about-as')); ?>">About Us</a></li>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('navigation')); ?>">Navigation</a></li>
                <?php if(!Auth::guest()): ?>
            <?php if(auth()->user()->user_type == 1): ?>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('certificate')); ?>">Certificate</a></li>
            <?php endif; ?>
            <?php endif; ?>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
            </ul>
            </div>
            <div class="col-lg-4 text-align-footer">
            <p class="redeemyourpoints-footer">Redeem Your Points</p>
            <a class="reedem-img" href="<?php echo e(route('redeemyourpoints')); ?>"><img class="buttom-redeem" src="../../../img/Reedem-final.png" alt="Redeem Your Points"></a>
            <a class="app-img" href="#"><img class="buttom-redeem" src="../../../img/Google-play-x1.png" alt="Google Play"></a>
            <a class="app-img" href="#"><img class="buttom-redeem" src="../../../img/App-Store-x1.png" alt="App Store"></a>  
            </div>
   </div>
  </div>



<div class="copyright">
<div class="container">
    <p class="footer-text">  Copyright © 2020 <a class="footer-egncda" href="https://www.egncda.org/">Egncda Organisation</a> All Rights Reserved</p>
</div>

        <div class="col-12  col-lg-2 text-align-footer footer-icon">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
</div>
</div>

</div>            

<?php $__env->stopSection(); ?>
<?php else: ?>
<?php
$host  = $_SERVER['HTTP_HOST'];
$host_upper = strtoupper($host);
header('Location:' . $host_upper );
exit;
?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/question/create.blade.php ENDPATH**/ ?>