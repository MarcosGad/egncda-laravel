<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container">
    <div id="chartContainer" style="height: 300px; width: 100%;"></div>
   </div>




   <script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,  
	title:{
		text: "Redeem Your Points"
	},
	data: [{
		type: "spline",
		dataPoints:<?php echo json_encode($data); ?>
	}]
});
chart.render();

}
</script>

  
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gixnbny6ri2v/public_html/resources/views/redeemyourpoints.blade.php ENDPATH**/ ?>