<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<?php if(auth()->user()->admin): ?>

<div class="wrapper">
<div class="body-admin">
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4">

            <ul class="nav flex-column">
                
            
            <li class="nav-item <?php echo e(request()->is('dashboard')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li> 
            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fas fa-plus"></i> Add</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>"><i class="fas fa-newspaper"></i> Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>"><i class="fas fa-star-of-life"></i> Conferences</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('users')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('users')); ?>"><i class="fas fa-users"></i> Users</a>
            </li> 
            <!-- logout -->
                <li class="nav-item <?php echo e(request()->is('logout')  ? 'active' : null); ?>">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
                         Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>

            </ul> 
            
            </div>
            <div class="col-lg-10 col-sm-8 ">
            <?php endif; ?>
                <div class="container">

                    <div class="row justify-content-center">
                        <div class="col-md-10">
                            <div class="card card-exam-one ">
                                <div class="card-header"><?php echo e($questionnaire->title); ?></div>
                                <div class="card-body">
                                <?php if(auth()->user()->admin): ?>
                                    <a class="btn btn-primary" href="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/create">Add New Question</a>
                                <?php else: ?>
                                <a class="btn btn-primary" href="/surveys/<?php echo e($questionnaire->id); ?>-<?php echo e(Str::slug($questionnaire->title)); ?>">Take Exam</a>
                                <?php endif; ?>
                                </div>
                            </div>
                        
                            <?php if(auth()->user()->admin): ?>
                            <?php $__currentLoopData = $questionnaire->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mt-4">
                                <div class="card-header"><?php echo e($question->question); ?></div>
                                <div class="card-body">
                                    <ul class="list-group">
                                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex justify-content-between">
                                        <div><?php echo e($answer->answer); ?></div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            
                            <div class="card-footer">
                                <form action="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/<?php echo e($question->id); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete Question</button>
                                </form>
                            </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
            </div>
            </div>
            <div class="adel">

            </div>

            <div class="footer">

<div class="container">
    <div class="row">
        <div class="col-lg-4 footer-ph">
           
        <img src="../img/logo-footer-final.png" class="logo-about" height="100px">
         

            </div>
            <div class="col-lg-4">
            
            
            <p class="loginas-footer">Services</p>
            <ul class="ul-footer">
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('welcome')); ?>">Home</a></li>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('about-as')); ?>">About Us</a></li>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('navigation')); ?>">Navigation</a></li>
                <?php if(!Auth::guest()): ?>
            <?php if(auth()->user()->user_type == 1): ?>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('certificate')); ?>">Certificate</a></li>
            <?php endif; ?>
            <?php endif; ?>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
            </ul>
            </div>
            <div class="col-lg-4 text-align-footer">
            <p class="redeemyourpoints-footer">Redeem Your Points</p>
            <a class="reedem-img" href="<?php echo e(route('redeemyourpoints')); ?>"><img class="buttom-redeem" src="../img/Reedem-final.png" alt="Redeem Your Points"></a>
            <a class="app-img" href="#"><img class="buttom-redeem" src="../img/Google-play-x1.png" alt="Google Play"></a>
            <a class="app-img" href="#"><img class="buttom-redeem" src="../img/App-Store-x1.png" alt="App Store"></a>  
            </div>
   </div>
  </div>



<div class="copyright">
<div class="container">
    <p class="footer-text">  Copyright © 2020 <a class="footer-egncda" href="https://www.egncda.org/">Egncda Organisation</a> All Rights Reserved</p>
</div>

        <div class="col-12  col-lg-2 text-align-footer footer-icon">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
</div>
</div>

</div>            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/questionnaire/show.blade.php ENDPATH**/ ?>