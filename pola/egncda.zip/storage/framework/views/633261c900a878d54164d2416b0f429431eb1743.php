<?php $__env->startComponent('mail::message'); ?>
# Thanks you for your message
<strong>Name</strong> <?php echo e($data['name']); ?>

<strong>Email</strong> <?php echo e($data['email']); ?>

<strong>Message</strong> <?php echo e($data['message']); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/emails/contact-form.blade.php ENDPATH**/ ?>