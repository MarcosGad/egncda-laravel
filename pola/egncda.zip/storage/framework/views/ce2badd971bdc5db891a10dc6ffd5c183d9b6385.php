
<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4 col-4">

            <ul class="nav flex-column">
                
            
            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Add</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>">Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('comment')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('comment')); ?>">Comment Eams</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>">Conferences</a>
            </li>
            <!-- logout -->
                <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                                       Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>
                

            </ul> 
            
            </div>
            <div class="col-lg-10 col-sm-8 col-8">
            <div class="container">
            <div class="row">
            <div class="col-md-8">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Middle Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Mr/Mrs</th>
                    <th scope="col">Dr</th>
                    <th scope="col">Prof</th>
                    <th scope="col">Nationality</th>
                    <th scope="col">Passport</th>
                    <th scope="col"> Affiliation</th>
                    <th scope="col">Mobile No</th>
                    <th scope="col">Email</th>
                    <th scope="col">Type Of Attendance</th>
                    <th scope="col">Type Of Contribution Submitted</th>
                    <th scope="col">Title Of The Contribution</th>
                    <th scope="col">Conference Fee</th>
                    <th scope="col">Conference Dinner</th>
                    <th scope="col">Total Amount</th>
                    <th scope="col">Money Order Issued On</th>
                    <th scope="col">Money Order Issued To</th>
                    <th scope="col">Created At</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $redeems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($redeem->id); ?></th>
                    <td><?php echo e($redeem->first_name); ?></td>
                    <td><?php echo e($redeem->middle_name); ?></td>
                    <td><?php echo e($redeem->last_name); ?></td>
                    <td><?php echo e($redeem->mr_mrs); ?></td>
                    <td><?php echo e($redeem->dr); ?></td>
                    <td><?php echo e($redeem->prof); ?></td>
                    <td><?php echo e($redeem->nationality); ?></td>
                    <td><?php echo e($redeem->passport); ?></td>
                    <td><?php echo e($redeem->affiliation); ?></td>
                    <td><?php echo e($redeem->mobile_no); ?></td>
                    <td><?php echo e($redeem->email); ?></td>
                    <td><?php echo e($redeem->type_of_attendance); ?></td>
                    <td><?php echo e($redeem->type_of_contribution_submitted); ?></td>
                    <td><?php echo e($redeem->title_of_the_contribution); ?></td>
                    <td><?php echo e($redeem->conference_fee); ?></td>
                    <td><?php echo e($redeem->conference_dinner); ?></td>
                    <td><?php echo e($redeem->total_amount); ?></td>
                    <td><?php echo e($redeem->money_order_issued_on); ?></td>
                    <td><?php echo e($redeem->money_order_issued_to); ?></td>
                    <td><?php echo e($redeem->created_at); ?></td>
                    <td>
                        <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="<?php echo e(route('confer.delete',['id'=>$redeem->id])); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>

            </div>
            </div>
            
          </div>
         
        </div>

       </div>
       <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gixnbny6ri2v/public_html/resources/views/confer.blade.php ENDPATH**/ ?>