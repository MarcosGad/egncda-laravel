
<div class="upper-bar">
<div class="container">
    <div class="row">
    
    <div class="col-12 col-lg-8 footer-ph">
     <p class="upper-bar-desc"><i class="far fa-envelope"></i> <a class="mail" href="mailto:info@egncda.com">info@egncda.com</a></p>
    </div>

    <div class="col-lg-2">    
    <a class="btn btn-primary" href="<?php echo e(route('redeemyourpoints')); ?>">Redeem Your Points</a>
    </div>  
    <?php if(!Auth::guest()): ?>
            <div class="col-lg-2">
            <p class="upper-bar-logout">
                <i class="fas fa-sign-out-alt"></i>
                <a class="" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                Log Out
                </a>                        
         
            </p>
           
            </div>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            </form>
    <?php endif; ?>
</div>
</div>
</div>
<?php /**PATH /home/gixnbny6ri2v/public_html/resources/views/upperbar.blade.php ENDPATH**/ ?>