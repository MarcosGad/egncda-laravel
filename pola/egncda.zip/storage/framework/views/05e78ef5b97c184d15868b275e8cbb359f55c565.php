
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
<!-- wrapper footer -->
<div class="wrapper">
<div class="container">
   
<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-inverse bg-inverse">
<a class="navbar-brand" href="<?php echo e(route('welcome')); ?>"><img src="img/logo-header.png" height="90px"></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item <?php echo e(Request::segment(1) === 'welcome' ? 'active' : null); ?>">
          <a class="nav-link" style="color:rgba(32, 211, 73, 1);" href="<?php echo e(route('welcome')); ?>">Home</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'about-as' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('about-as')); ?>">About As</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'navigation' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('navigation')); ?>">Navigation</a>
      </li>

     <?php if(!Auth::guest()): ?>
     <?php if(auth()->user()->user_type == 1): ?>
      <li class="nav-item <?php echo e(Request::segment(1) === 'certificate' ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('certificate')); ?>">Certificate</a>
      </li>
     <?php endif; ?>
     <?php endif; ?>
      
      <li class="nav-item <?php echo e(Request::segment(1) === 'contactus' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('contactus')); ?>">Contact Us</a>
      </li>
      
     
    </ul>
    
    <form method="GET" action="/results" class="form-inline my-2 my-lg-0">
        <?php echo e(csrf_field()); ?>

      <div class="flexbox">
        <div class="search">
          <div>
            <input type="text" name="search" placeholder="       Search . . ." required>
          </div>
        </div>
      </div>
    </form>


  </div>
</nav>
</div>

    
<div class="container-fluid">
    <div class="card-deck">                       
        <div class="row">
               
                <?php $__currentLoopData = $categoriesofdoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriesofdoctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="col-md-4"> 
                      <a href="/miscellaneous-<?php echo e(Str::slug($categoriesofdoctor->name)); ?>"  style="text-decoration:none">
                             
                        <div class="card card-icon">
                        <p class="book-mange"><i class="fas <?php echo e($categoriesofdoctor->icon); ?>"></i></p>
                         
                         <hr>
                         
                         <div class="card-body">
                           <h5 class="card-title"><?php echo e($categoriesofdoctor->name); ?></h5>
                         </div>
                         
                      </div>
                       </a>
                    </div> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 

        </div>
    </div> 
</div>





<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gixnbny6ri2v/public_html/resources/views/miscellaneous-doctor.blade.php ENDPATH**/ ?>