<div class="footer">

<div class="container">
    <div class="row">

        <div class="col-lg-4 footer-ph">   
             <img src="img/logo-footer-final.png" class="logo-about" height="100px">
        </div>

        <div class="col-lg-4">
            <p class="loginas-footer">Services</p>
            <ul class="ul-footer">
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('welcome')); ?>">Home</a></li>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('about-as')); ?>">About Us</a></li>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('navigation')); ?>">Navigation</a></li>
                
            <?php if(!Auth::guest()): ?>
            <?php if(auth()->user()->user_type == 1): ?>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('certificate')); ?>">Certificate</a></li>
            <?php endif; ?>
            <?php endif; ?>
                <li><i class="fas fa-chevron-right"></i> <a  href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
            </ul>
        </div>

        <div class="col-lg-4 text-align-footer">
            <p class="redeemyourpoints-footer">Redeem Your Points</p>
            <a class="reedem-img" href="<?php echo e(route('redeemyourpoints')); ?>"><img class="buttom-redeem" src="img/Reedem-final.png" alt="Redeem Your Points"></a>
            <a class="app-img" href="#"><img class="buttom-redeem" src="img/Google-play-x1.png" alt="Google Play"></a>
            <a class="app-img" href="#"><img class="buttom-redeem" src="img/App-Store-x1.png" alt="App Store"></a>   
        </div>

   </div>
</div>



<div class="copyright">
<div class="container">
    <p class="footer-text">  Copyright © 2020 <a class="footer-egncda" href="https://www.egncda.org/">Egncda Organisation</a> All Rights Reserved</p>
</div>
        <div class="col-12  col-lg-2 text-align-footer footer-icon">
                <a href="https://www.facebook.com/EGNCDA/"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/EGNCDA?s=20"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="https://www.youtube.com/channel/UCwO3rB9rh5-qVKAIl2n7tgQ"><i class="fab fa-youtube"></i></a>
        </div>
</div>
</div>

</div><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/layouts/footer.blade.php ENDPATH**/ ?>