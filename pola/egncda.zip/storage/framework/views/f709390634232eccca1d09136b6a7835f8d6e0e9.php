<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
<div class="container-fluid">
          <div class="row justify-content-center">
                <div class="col-lg-10 col-sm-8 col-8">
                    <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success result-massage">
                        <?php echo \Session::get('success'); ?>

                    </div>
                    <?php endif; ?>
                </div>

    </div>
    </div>
            

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/massage.blade.php ENDPATH**/ ?>