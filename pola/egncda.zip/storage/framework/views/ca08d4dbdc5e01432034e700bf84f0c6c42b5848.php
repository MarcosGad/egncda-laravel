<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
   
<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-inverse bg-inverse">
<a class="navbar-brand" href="<?php echo e(route('welcome')); ?>"><img src="img/logo-header.png" height="90px"></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item <?php echo e(Request::segment(1) === 'welcome' ? 'active' : null); ?>">
          <a class="nav-link" style="color:rgba(32, 211, 73, 1);" href="<?php echo e(route('welcome')); ?>">Home</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'about-as' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('about-as')); ?>">About As</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'navigation' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('navigation')); ?>">Navigation</a>
      </li>

     <?php if(!Auth::guest()): ?>
     <?php if(auth()->user()->user_type == 1): ?>
      <li class="nav-item <?php echo e(Request::segment(1) === 'certificate' ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('certificate')); ?>">Certificate</a>
      </li>
     <?php endif; ?>
     <?php endif; ?>
      
      <li class="nav-item <?php echo e(Request::segment(1) === 'contactus' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('contactus')); ?>">Contact Us</a>
      </li>
      
     
    </ul>
    


  </div>
</nav>
</div>
<div class="container">
        <div class="row">
                       <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                                <div class="card card-book" style="width: 18rem;">
                                <img class="card-img-upload" src="<?php echo e($book->photo_book); ?>" alt="Card image cap">
                                <div class="card-body">	
                                <h5 class="card-title"><?php echo e($book->name_book); ?></h5>
                                <a class="btn btn-primary" href="<?php echo e($book->pdf_book); ?>">Download</a>
                                <a class="btn btn-primary" href="<?php echo e($book->pre_book); ?>" target="_blank">Preview</a>
                                <a class="btn btn-primary" href="/uploads/<?php echo e($book->id); ?>" target="_blank">view</a>
                                </div>
                                </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
        </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/respiratory-definition-pathogenesis-pathophysiology-risk-factors-of-copd.blade.php ENDPATH**/ ?>