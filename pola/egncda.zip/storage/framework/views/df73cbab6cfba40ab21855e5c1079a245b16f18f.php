<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php if(auth()->user()->user_type): ?>




<div class="container">
   
<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-inverse bg-inverse">
<a class="navbar-brand" href="<?php echo e(route('welcome')); ?>"><img src="img/logo-header.png" height="90px"></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

    
    <li class="nav-item <?php echo e(Request::segment(1) === 'welcome' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('welcome')); ?>">Home</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'about-as' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('about-as')); ?>">About As</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'navigation' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('navigation')); ?>">Navigation</a>
      </li>

      <?php if(!Auth::guest()): ?>
     <?php if(auth()->user()->user_type == 1): ?>
      <li class="nav-item <?php echo e(Request::segment(1) === 'certificate' ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('certificate')); ?>">Certificate</a>
      </li>
     <?php endif; ?>
     <?php endif; ?>

      <li class="nav-item <?php echo e(Request::segment(1) === 'contactus' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('contactus')); ?>">Contact Us</a>
      </li>
      
      
     
    </ul>
    <form method="GET" action="/results" class="form-inline my-2 my-lg-0">
        <?php echo e(csrf_field()); ?>

      <div class="flexbox">
        <div class="search">
          <div>
            <input type="text" name="search" placeholder="       Search . . ." required>
          </div>
        </div>
      </div>
    </form>
  </div>
</nav>
</div>

    <div class="medical">
     <div class="container-fluid">
         <div class="row">
                    
            <div class="col-sm-6">  
             <div class="gallery-two">
               <div>          
               <a href="<?php echo e(route('medical')); ?>"><img src="img/m.jpg" class="img-doctor" alt="Medical"><span class="overlay-two"></span></a>
                </div>
                <div>
                <p class="parent-icon-two"><i class="fas fa-briefcase-medical"></i></p>
                </div>
             </div>
             
                <h5 class="title-do">Medical</h5>
            </div>


            <div class="col-sm-6">
            <div class="gallery-two">
            <div>    
                <a href="<?php echo e(route('social')); ?>"><img src="img/s.jpg" class="img-doctor" alt="Social" ><span class="overlay-two"></span></a>
                </div> 
                <div>
                <p class="parent-icon-two"><i class="fas fa-share-alt"></i></p>
                </div> 
             </div>
             
                <h5 class="title-do">Social</h5>
            </div>

           </div>   
     </div>
    </div>  
   

    <?php elseif(auth()->user()->admin): ?>
    <div class="wrapper">     
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4 col-4">

            <ul class="nav flex-column">
                
            
            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Add</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>">Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('comment')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('comment')); ?>">Comment Eams</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>">Conferences</a>
            </li>
            <!-- logout -->
                <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                                       Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>
                

            </ul> 
            
            </div>
            <div class="col-lg-10 col-sm-8 col-8">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card card-admin">
                            <div class="card-body">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                                <form action="<?php echo e(route('add')); ?>" method="Post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                
                                    <div class="form-group row">
                                        <label for="name_book">Name Of Book</label>

                                        <div class="col-md-6">
                                            <input id="name_book" type="text" class="form-control <?php $__errorArgs = ['name_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name_book" required >
                                            <?php $__errorArgs = ['name_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="pre_book">Link Google</label>

                                        <div class="col-md-6">
                                            <input id="pre_book" type="text" class="form-control <?php $__errorArgs = ['pre_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pre_book" required >
                                            <?php $__errorArgs = ['pre_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="desc">Link</label>

                                        <div class="col-md-6">
                                        <textarea class="form-control <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="content" name="desc" rows="8" cols="8" required></textarea>
                                            <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                    <label for="photo_book">Photo</label>

                                    <div class="col-md-6">
                                            <input id="photo_book" type="file" class="form-control-file" name="photo_book" required>
                                        </div>

                                    </div>

                                    <div class="form-group row">
                                    <label for="pdf_book">PDF</label>

                                    <div class="col-md-6">
                                            <input id="pdf_book" type="file" class="form-control-file" name="pdf_book" required>
                                        </div>

                                    </div>

                                    <div class="form-group">
                                    <label for="cat_id">Cat</label>
                                    <select class="form-control cat" name="cat_id" id="cat">
                                     
                                     <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($cat->id); ?>" ><?php echo e($cat->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    </select>
                                    </div>

                                    
                                    <div class="form-group">
                                    <label for="categoriesofdoctors_id">Categories of Doctors</label>
                                    <select class="form-control" name="categoriesofdoctors_id" id="select_box">
                                     
                                     <?php $__currentLoopData = $categoriesofdoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriesofdoctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($categoriesofdoctor->id); ?>" ><?php echo e($categoriesofdoctor->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>

                                   
                                   
                                    <div class="form-group one">
                                    <label for="basicmanagements_id">Categories of Doctors</label>
                                    <select class="form-control" name="basicmanagements_id" id="select_box_two">

                                    <option value="0">select......</option>
                                     
                                     <?php $__currentLoopData = $basicmanagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basicmanagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($basicmanagement->id); ?>" ><?php echo e($basicmanagement->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                    
                                    </div>

                                 
                                    <div class="form-group two">
                                    <label for="cvscurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="cvscurriculums_id" id="cvscurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $cvscurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvscurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($cvscurriculum->id); ?>" ><?php echo e($cvscurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>


                                    <div class="form-group three">
                                    <label for="diabetescurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="diabetescurriculums_id" id="diabetescurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $diabetescurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diabetescurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($diabetescurriculum->id); ?>" ><?php echo e($diabetescurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>


                                    <div class="form-group four">
                                    <label for="respiratorycurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="respiratorycurriculums_id" id="respiratorycurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $respiratorycurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respiratorycurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($respiratorycurriculum->id); ?>" ><?php echo e($respiratorycurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>

   
                              <div class="form-group five">
                                    <label for="miscellaneouscurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="miscellaneouscurriculums_id" id="miscellaneouscurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $miscellaneouscurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miscellaneouscurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($miscellaneouscurriculum->id); ?>" ><?php echo e($miscellaneouscurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>

                                

                                    <button type="submit" class="btn btn-primary">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
          </div>
        </div>

        <a href="<?php echo e(route('add-codes')); ?>" class="btn btn-primary">Add Codes</a>

   <?php elseif(auth()->user()->user_type == 0): ?>

    <div class="container">
   
<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-inverse bg-inverse">
<a class="navbar-brand" href="<?php echo e(route('welcome')); ?>"><img src="img/logo-header.png" height="90px"></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

    
    <li class="nav-item <?php echo e(Request::segment(1) === 'welcome' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('welcome')); ?>">Home</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'about-as' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('about-as')); ?>">About As</a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) === 'navigation' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('navigation')); ?>">Navigation</a>
      </li>

      <?php if(!Auth::guest()): ?>
     <?php if(auth()->user()->user_type == 1): ?>
      <li class="nav-item <?php echo e(Request::segment(1) === 'certificate' ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('certificate')); ?>">Certificate</a>
      </li>
     <?php endif; ?>
     <?php endif; ?>

      <li class="nav-item <?php echo e(Request::segment(1) === 'contactus' ? 'active' : null); ?>">
          <a class="nav-link" href="<?php echo e(route('contactus')); ?>">Contact Us</a>
      </li>
      
      
     
    </ul>
    <form method="GET" action="/results" class="form-inline my-2 my-lg-0">
        <?php echo e(csrf_field()); ?>

      <div class="flexbox">
        <div class="search">
          <div>
            <input type="text" name="search" placeholder="       Search . . ." required>
          </div>
        </div>
      </div>
    </form>
  </div>
</nav>
</div>

    <div class="medical">
     <div class="container-fluid">
        <div class="row">
                    
            <div class="col-sm-4">  
            <div class="gallery-four">
            <div>          
            <a href="#"><img src="img/3333.jpg" class="img-doctor" alt=""><span class="overlay-four"></span></a>
                </div>
                <div>
                <p class="parent-icon-four"><i class="fas fa-utensils"></i></p>
                </div>
            </div>
            
                <h5 class="title-do">التوصيات الغذائية " كل ولا تاكل"</h5>
            </div>


            <div class="col-sm-4">
            <div class="gallery-four">
            <div>    
                <a href="#"><img src="img/5555.jpg" class="img-doctor" alt="" ><span class="overlay-four"></span></a>
                </div> 
                <div>
                <p class="parent-icon-four"><i class="fas fa-dumbbell"></i></p>
                </div> 
            </div>
            
                <h5 class="title-do">أساليب تعديل نمط الحياة</h5>
            </div>

            <div class="col-sm-4">
            <div class="gallery-four">
            <div>    
                <a href="#"><img src="img/4444.jpg" class="img-doctor" alt="" ><span class="overlay-four"></span></a>
                </div> 
                <div>
                <p class="parent-icon-four"><i class="fas fa-calendar-plus"></i></p>
                </div> 
            </div>
            
                <h5 class="title-do">احداث توعية</h5>
            </div>

        </div>   
     </div>
    </div>


<?php endif; ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gixnbny6ri2v/public_html/resources/views/dash.blade.php ENDPATH**/ ?>