
<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4 col-4">

            <ul class="nav flex-column">
                
            
            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Add</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>">Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('comment')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('comment')); ?>">Comment Eams</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>">Conferences</a>
            </li>
            <!-- logout -->
                <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                                       Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>
                

            </ul> 
            
            </div>
            <div class="col-lg-10 col-sm-8 col-8">
            <div class="container">
            <div class="row justify-content-center">
            <div class="col-md-8">
            <div class="card">
                <div class="card-header">Exams</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="/questionnaires/create" class="btn btn-dark">Create New Exam</a>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header">My Exams</div>

                <div class="card-body">
                    <ul class="list-group">
                      <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="list-group-item">
                             <a href="<?php echo e($questionnaire->path()); ?>"><?php echo e($questionnaire->title); ?></a>
                          </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

        </div>
    </div>
            </div>
            </div>
          </div>
        </div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gixnbny6ri2v/public_html/resources/views/exm.blade.php ENDPATH**/ ?>