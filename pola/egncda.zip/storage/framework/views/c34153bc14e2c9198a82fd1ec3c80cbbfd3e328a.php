<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
<div class="body-admin">
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4">

            <ul class="nav flex-column">

            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li> 
                
            <li class="nav-item <?php echo e(request()->is('add')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('add')); ?>"><i class="fas fa-plus"></i> Add</a>
            </li>
            
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>"><i class="fas fa-newspaper"></i> Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>"><i class="fas fa-star-of-life"></i> Conferences</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('users')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('users')); ?>"><i class="fas fa-users"></i> Users</a>
            </li> 
            <!-- logout -->
                <li class="nav-item <?php echo e(request()->is('logout')  ? 'active' : null); ?>">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
                         Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>

            </ul> 
            
            </div>
        <div class="col-lg-10 col-sm-8">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-10">
                        <div class="card card-admin">
                            <div class="card-body">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                                <form action="<?php echo e(route('add')); ?>" method="Post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                
                                    <div class="form-group row">
                                        <label for="name_book">Name Of Book</label>

                                        <div class="col-md-6">
                                            <input id="name_book" type="text" class="form-control <?php $__errorArgs = ['name_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name_book" required >
                                            <?php $__errorArgs = ['name_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="pre_book">Link Google</label>

                                        <div class="col-md-6">
                                            <input id="pre_book" type="text" class="form-control <?php $__errorArgs = ['pre_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pre_book" required >
                                            <?php $__errorArgs = ['pre_book'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="desc">Link</label>

                                        <div class="col-md-10">
                                        <textarea class="form-control <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="content" name="desc" rows="8" cols="8"></textarea>
                                            <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                    <label for="photo_book">Photo</label>

                                    <div class="col-md-6">
                                            <input id="photo_book" type="file" class="form-control-file" name="photo_book" required>
                                        </div>

                                    </div>

                                    <div class="form-group row">
                                    <label for="pdf_book">PDF</label>

                                    <div class="col-md-6">
                                            <input id="pdf_book" type="file" class="form-control-file" name="pdf_book" required>
                                        </div>

                                    </div>

                                    <div class="form-group">
                                    <label for="cat_id">Cat</label>
                                    <select class="form-control cat" name="cat_id" id="cat">
                                     
                                     <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($cat->id); ?>" ><?php echo e($cat->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    </select>
                                    </div>

                                    
                                    <div class="form-group">
                                    <label for="categoriesofdoctors_id">Categories of Doctors</label>
                                    <select class="form-control" name="categoriesofdoctors_id" id="select_box">
                                    <option value="0">select......</option>
                                     <?php $__currentLoopData = $categoriesofdoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriesofdoctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($categoriesofdoctor->id); ?>" ><?php echo e($categoriesofdoctor->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>

                                   
                                   
                                    <div class="form-group one">
                                    <label for="basicmanagements_id">Categories of Doctors</label>
                                    <select class="form-control" name="basicmanagements_id" id="select_box_two">

                                    <option value="0">select......</option>
                                     
                                     <?php $__currentLoopData = $basicmanagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basicmanagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($basicmanagement->id); ?>" ><?php echo e($basicmanagement->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                    
                                    </div>

                                 
                                    <div class="form-group two">
                                    <label for="cvscurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="cvscurriculums_id" id="cvscurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $cvscurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cvscurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($cvscurriculum->id); ?>" ><?php echo e($cvscurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>


                                    <div class="form-group three">
                                    <label for="diabetescurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="diabetescurriculums_id" id="diabetescurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $diabetescurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diabetescurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($diabetescurriculum->id); ?>" ><?php echo e($diabetescurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>


                                    <div class="form-group four">
                                    <label for="respiratorycurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="respiratorycurriculums_id" id="respiratorycurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $respiratorycurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respiratorycurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($respiratorycurriculum->id); ?>" ><?php echo e($respiratorycurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>

   
                              <div class="form-group five">
                                    <label for="miscellaneouscurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="miscellaneouscurriculums_id" id="miscellaneouscurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $miscellaneouscurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miscellaneouscurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($miscellaneouscurriculum->id); ?>" ><?php echo e($miscellaneouscurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>

                                    <div class="form-group six">
                                    <label for="oncolcgycurriculums_id">Categories of Curriculums</label>
                                    <select class="form-control" name="oncolcgycurriculums_id" id="oncolcgycurriculums_id">
                                     
                                    <option value="0">select......</option>

                                     <?php $__currentLoopData = $oncolcgycurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oncolcgycurriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($oncolcgycurriculum->id); ?>" ><?php echo e($oncolcgycurriculum->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    </select>
                                   
                                    </div>

                                

                                    <button type="submit" class="btn btn-primary">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    
         </div>
            

        <a href="<?php echo e(route('add-codes')); ?>" class="btn btn-primary" style="display:none;">Add Codes</a>

        </div>    
       <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/dashboard.blade.php ENDPATH**/ ?>