<?php echo $__env->make('upperbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
<div class="body-admin">
<div class="container-fluid">
          <div class="row">
            <div class="col-lg-2 col-sm-4">

            <ul class="nav flex-column">
                
            <li class="nav-item <?php echo e(request()->is('home')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li> 
                
            <li class="nav-item <?php echo e(request()->is('add')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('add')); ?>"><i class="fas fa-plus"></i> Add</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('exm')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('exm')); ?>"><i class="fas fa-newspaper"></i> Exm</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('confer')  ? 'active' : null); ?>">
                    <a class="nav-link" href="<?php echo e(route('confer')); ?>"><i class="fas fa-star-of-life"></i> Conferences</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('users')  ? 'active' : null); ?>">
             <a class="nav-link" href="<?php echo e(route('users')); ?>"><i class="fas fa-users"></i> Users</a>
            </li> 
            <!-- logout -->
                <li class="nav-item <?php echo e(request()->is('logout')  ? 'active' : null); ?>">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
                         Log Out
                </a>                        
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>

            </ul> 
            
            </div>
            <div class="col-lg-10 col-sm-8">
            <div class="container">
            <div class="row">
            <div class="col-md-10">
            <table class="table table-responsive">
                <thead class="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Score</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td><?php echo e($user->first_name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->scoure); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>

            </div>
            </div>
            
          </div>
         
        </div>

       </div>
       </div>
       <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polycarpus\Desktop\egncda\resources\views/users.blade.php ENDPATH**/ ?>